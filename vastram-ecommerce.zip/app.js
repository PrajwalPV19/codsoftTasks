// Vastram E-commerce Application
class VastramApp {
    constructor() {
        this.currentPage = 'home';
        this.currentCurrency = 'INR';
        this.currentLanguage = 'en';
        this.currentUser = null;
        this.cart = [];
        this.filters = {
            search: '',
            fabric: '',
            color: '',
            occasion: '',
            sort: 'featured'
        };
        
        this.init();
    }

    // Sample data
    products = [
        {
            id: 1,
            title: "Kanjivaram Silk Saree - Ruby Glow",
            slug: "kanjivaram-silk-ruby-glow",
            description: "Handwoven Kanjivaram with zari border. A stunning piece that embodies traditional craftsmanship with contemporary elegance.",
            fabric: "Silk",
            color: "Red",
            occasion: "Wedding",
            price_inr: 8999,
            compare_at_inr: 12999,
            stock: 25,
            rating: 4.8,
            images: ["/assets/p1-1.jpg", "/assets/p1-2.jpg"],
            attributes: {"length": "5.5m", "blouse_piece": "0.8m"}
        },
        {
            id: 2,
            title: "Chiffon Saree - Mist Blue",
            slug: "chiffon-mist-blue",
            description: "Lightweight chiffon with shimmer pallu. Perfect for parties and special occasions.",
            fabric: "Chiffon",
            color: "Blue",
            occasion: "Party",
            price_inr: 2499,
            compare_at_inr: 3499,
            stock: 40,
            rating: 4.6,
            images: ["/assets/p2-1.jpg", "/assets/p2-2.jpg"],
            attributes: {"length": "5.5m", "blouse_piece": "0.8m"}
        },
        {
            id: 3,
            title: "Cotton Silk Saree - Meadow Green",
            slug: "cotton-silk-meadow-green",
            description: "Breathable cotton-silk blend. Comfortable for all-day wear with elegant drape.",
            fabric: "Cotton-Silk",
            color: "Green",
            occasion: "Festive",
            price_inr: 3199,
            compare_at_inr: 4199,
            stock: 30,
            rating: 4.7,
            images: ["/assets/p3-1.jpg"],
            attributes: {"length": "5.5m", "blouse_piece": "0.8m"}
        },
        {
            id: 4,
            title: "Banarasi Silk Saree - Golden Elegance",
            slug: "banarasi-silk-golden-elegance",
            description: "Traditional Banarasi silk with intricate golden work. Perfect for weddings and special occasions.",
            fabric: "Silk",
            color: "Gold",
            occasion: "Wedding",
            price_inr: 11999,
            compare_at_inr: 15999,
            stock: 15,
            rating: 4.9,
            images: ["/assets/p4-1.jpg"],
            attributes: {"length": "5.5m", "blouse_piece": "0.8m"}
        },
        {
            id: 5,
            title: "Georgette Saree - Midnight Black",
            slug: "georgette-midnight-black",
            description: "Elegant black georgette with delicate embroidery. Ideal for evening parties.",
            fabric: "Georgette",
            color: "Black",
            occasion: "Party",
            price_inr: 3599,
            compare_at_inr: 4999,
            stock: 35,
            rating: 4.5,
            images: ["/assets/p5-1.jpg"],
            attributes: {"length": "5.5m", "blouse_piece": "0.8m"}
        },
        {
            id: 6,
            title: "Cotton Saree - Rose Pink",
            slug: "cotton-rose-pink",
            description: "Pure cotton saree in beautiful rose pink. Comfortable for daily wear and casual occasions.",
            fabric: "Cotton",
            color: "Pink",
            occasion: "Casual",
            price_inr: 1599,
            compare_at_inr: 2199,
            stock: 50,
            rating: 4.4,
            images: ["/assets/p6-1.jpg"],
            attributes: {"length": "5.5m", "blouse_piece": "0.8m"}
        },
        {
            id: 7,
            title: "Organza Saree - Royal Purple",
            slug: "organza-royal-purple",
            description: "Luxurious organza saree in royal purple with golden border. Perfect for festive occasions.",
            fabric: "Organza",
            color: "Purple",
            occasion: "Festive",
            price_inr: 4999,
            compare_at_inr: 6999,
            stock: 20,
            rating: 4.7,
            images: ["/assets/p7-1.jpg"],
            attributes: {"length": "5.5m", "blouse_piece": "0.8m"}
        },
        {
            id: 8,
            title: "Linen Saree - Sky Blue",
            slug: "linen-sky-blue",
            description: "Breathable linen saree in refreshing sky blue. Perfect for summer and office wear.",
            fabric: "Linen",
            color: "Blue",
            occasion: "Casual",
            price_inr: 2299,
            compare_at_inr: 2999,
            stock: 45,
            rating: 4.3,
            images: ["/assets/p8-1.jpg"],
            attributes: {"length": "5.5m", "blouse_piece": "0.8m"}
        }
    ];

    currencies = {
        INR: { symbol: "₹", rate: 1 },
        USD: { symbol: "$", rate: 0.012 },
        EUR: { symbol: "€", rate: 0.011 },
        GBP: { symbol: "£", rate: 0.0095 },
        AUD: { symbol: "A$", rate: 0.017 }
    };

    translations = {
        en: {
            "nav.shop": "Shop",
            "nav.collections": "Collections",
            "nav.about": "About",
            "nav.contact": "Contact",
            "cta.shop_now": "Shop Now",
            "product.add_to_cart": "Add to Cart",
            "product.buy_now": "Buy Now",
            "cart.title": "Your Cart",
            "checkout.title": "Checkout"
        },
        hi: {
            "nav.shop": "खरीदें",
            "nav.collections": "संग्रह",
            "nav.about": "हमारे बारे में",
            "nav.contact": "संपर्क",
            "cta.shop_now": "अभी खरीदें",
            "product.add_to_cart": "कार्ट में जोड़ें",
            "product.buy_now": "अभी खरीदें",
            "cart.title": "आपकी कार्ट",
            "checkout.title": "चेकआउट"
        }
    };

    coupons = [
        { code: "WELCOME10", type: "percent", value: 10, min_subtotal: 1999 }
    ];

    shipping = {
        IN: { name: "India", flat_rate: 99, free_over: 1999 },
        WW: { name: "Rest of World", flat_rate: 999, free_over: 9999 }
    };

    init() {
        this.loadCart();
        this.setupEventListeners();
        this.renderCurrentPage();
        this.updateCartCount();
    }

    setupEventListeners() {
        // Logo navigation - fixed
        document.querySelector('.logo').addEventListener('click', (e) => {
            e.preventDefault();
            this.navigateTo('home');
        });

        // Navigation
        document.querySelectorAll('[data-page]').forEach(link => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                e.stopPropagation();
                const page = e.target.getAttribute('data-page');
                this.navigateTo(page);
            });
        });

        // Currency selector
        document.querySelector('.currency-selector').addEventListener('change', (e) => {
            this.currentCurrency = e.target.value;
            this.renderCurrentPage();
        });

        // Language selector
        document.querySelector('.language-selector').addEventListener('change', (e) => {
            this.currentLanguage = e.target.value;
            this.updateLanguage();
        });

        // Search
        document.querySelector('.search-btn').addEventListener('click', () => {
            this.toggleSearchModal();
        });

        document.querySelector('.search-close').addEventListener('click', () => {
            this.toggleSearchModal();
        });

        document.querySelector('.search-input').addEventListener('input', (e) => {
            this.debounce(() => this.handleSearch(e.target.value), 250)();
        });

        // Filters
        document.querySelectorAll('.filter-search, .filter-fabric, .filter-color, .filter-occasion, .filter-sort').forEach(filter => {
            filter.addEventListener('change', (e) => {
                this.updateFilters(e);
            });
            filter.addEventListener('input', (e) => {
                this.debounce(() => this.updateFilters(e), 250)();
            });
        });

        // Newsletter form
        document.getElementById('newsletter-form').addEventListener('submit', (e) => {
            e.preventDefault();
            this.handleNewsletterSignup(e);
        });

        // Modal close handlers
        document.querySelectorAll('.modal__backdrop, .modal__close').forEach(element => {
            element.addEventListener('click', () => {
                this.closeAllModals();
            });
        });

        // Auth form handlers
        document.getElementById('login-form').addEventListener('submit', (e) => {
            e.preventDefault();
            this.handleLogin(e);
        });

        // Auth switch buttons
        document.querySelectorAll('.auth-switch-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                this.switchAuthForm(e.target.getAttribute('data-form'));
            });
        });
    }

    navigateTo(page, params = {}) {
        this.currentPage = page;
        this.hideAllPages();
        this.showPage(page);
        this.renderCurrentPage(params);
    }

    hideAllPages() {
        document.querySelectorAll('.page').forEach(page => {
            page.classList.add('hidden');
        });
    }

    showPage(page) {
        const pageElement = document.getElementById(`page-${page}`);
        if (pageElement) {
            pageElement.classList.remove('hidden');
        }
    }

    renderCurrentPage(params = {}) {
        switch (this.currentPage) {
            case 'home':
                this.renderHomePage();
                break;
            case 'collections':
                this.renderCollectionsPage();
                break;
            case 'product':
                this.renderProductPage(params.slug);
                break;
            case 'cart':
                this.renderCartPage();
                break;
            case 'checkout':
                this.renderCheckoutPage();
                break;
            case 'account':
                this.renderAccountPage();
                break;
            case 'admin':
                this.renderAdminPage();
                break;
        }
    }

    renderHomePage() {
        this.renderFeaturedProducts();
    }

    renderFeaturedProducts() {
        const container = document.getElementById('featured-products-grid');
        const featuredProducts = this.products.slice(0, 8);
        
        container.innerHTML = featuredProducts.map(product => 
            this.createProductCard(product)
        ).join('');

        this.attachProductCardListeners();
    }

    renderCollectionsPage() {
        const container = document.getElementById('collections-grid');
        const filteredProducts = this.getFilteredProducts();
        
        if (filteredProducts.length === 0) {
            container.innerHTML = `
                <div class="empty-state">
                    <h3>No products found</h3>
                    <p>Try adjusting your filters or search terms.</p>
                </div>
            `;
            return;
        }

        container.innerHTML = filteredProducts.map(product => 
            this.createProductCard(product)
        ).join('');

        this.attachProductCardListeners();
    }

    renderProductPage(slug) {
        if (!slug) return;
        
        const product = this.products.find(p => p.slug === slug);
        if (!product) return;

        const container = document.getElementById('product-detail-content');
        const price = this.convertPrice(product.price_inr);
        const originalPrice = this.convertPrice(product.compare_at_inr);
        
        container.innerHTML = `
            <div class="product-detail__images">
                <div class="product-detail__main-image">
                    <div class="product-image-placeholder">
                        <svg width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1">
                            <rect x="3" y="3" width="18" height="18" rx="2" ry="2"/>
                            <circle cx="8.5" cy="8.5" r="1.5"/>
                            <polyline points="21,15 16,10 5,21"/>
                        </svg>
                        <p>Product Image</p>
                    </div>
                </div>
                <div class="product-detail__thumbnails">
                    ${product.images.map((img, index) => `
                        <div class="product-detail__thumbnail ${index === 0 ? 'active' : ''}" data-image="${img}">
                            <div class="product-image-placeholder">
                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1">
                                    <rect x="3" y="3" width="18" height="18" rx="2" ry="2"/>
                                    <circle cx="8.5" cy="8.5" r="1.5"/>
                                    <polyline points="21,15 16,10 5,21"/>
                                </svg>
                            </div>
                        </div>
                    `).join('')}
                </div>
            </div>
            
            <div class="product-detail__info">
                <h1>${product.title}</h1>
                
                <div class="product-detail__rating">
                    <div class="rating-stars">
                        ${this.generateStars(product.rating)}
                    </div>
                    <span class="rating-value">${product.rating}/5</span>
                </div>
                
                <div class="product-detail__price">
                    <span class="product-detail__current-price">${price.symbol}${price.amount}</span>
                    ${product.compare_at_inr ? `<span class="product-detail__original-price">${originalPrice.symbol}${originalPrice.amount}</span>` : ''}
                </div>
                
                <p class="product-detail__description">${product.description}</p>
                
                <div class="product-detail__attributes">
                    <h3>Details</h3>
                    <div class="product-detail__attribute">
                        <span>Fabric</span>
                        <span>${product.fabric}</span>
                    </div>
                    <div class="product-detail__attribute">
                        <span>Color</span>
                        <span>${product.color}</span>
                    </div>
                    <div class="product-detail__attribute">
                        <span>Occasion</span>
                        <span>${product.occasion}</span>
                    </div>
                    <div class="product-detail__attribute">
                        <span>Length</span>
                        <span>${product.attributes.length}</span>
                    </div>
                    <div class="product-detail__attribute">
                        <span>Blouse Piece</span>
                        <span>${product.attributes.blouse_piece}</span>
                    </div>
                </div>
                
                <div class="product-detail__actions">
                    <button class="btn btn--primary add-to-cart-btn" data-product-id="${product.id}">
                        ${this.t('product.add_to_cart')}
                    </button>
                    <button class="btn btn--ghost buy-now-btn" data-product-id="${product.id}">
                        ${this.t('product.buy_now')}
                    </button>
                </div>
            </div>
        `;

        // Attach event listeners
        container.querySelector('.add-to-cart-btn').addEventListener('click', (e) => {
            this.addToCart(product.id);
        });

        container.querySelector('.buy-now-btn').addEventListener('click', (e) => {
            this.addToCart(product.id);
            this.navigateTo('cart');
        });

        // Image gallery functionality
        container.querySelectorAll('.product-detail__thumbnail').forEach(thumb => {
            thumb.addEventListener('click', (e) => {
                container.querySelectorAll('.product-detail__thumbnail').forEach(t => t.classList.remove('active'));
                e.currentTarget.classList.add('active');
            });
        });
    }

    renderCartPage() {
        const container = document.getElementById('cart-content');
        
        if (this.cart.length === 0) {
            container.innerHTML = `
                <div class="empty-state">
                    <h3>Your cart is empty</h3>
                    <p>Add some beautiful sarees to get started.</p>
                    <button class="btn btn--primary" data-page="collections">Continue Shopping</button>
                </div>
            `;
            
            container.querySelector('[data-page]').addEventListener('click', (e) => {
                e.preventDefault();
                this.navigateTo('collections');
            });
            return;
        }

        const subtotal = this.calculateSubtotal();
        const shipping = this.calculateShipping(subtotal);
        const total = subtotal + shipping;
        const convertedSubtotal = this.convertPrice(subtotal);
        const convertedShipping = this.convertPrice(shipping);
        const convertedTotal = this.convertPrice(total);

        container.innerHTML = `
            <div class="cart-table">
                <table>
                    <thead>
                        <tr>
                            <th>Product</th>
                            <th>Price</th>
                            <th>Quantity</th>
                            <th>Total</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${this.cart.map(item => {
                            const product = this.products.find(p => p.id === item.productId);
                            const price = this.convertPrice(product.price_inr);
                            const itemTotal = this.convertPrice(product.price_inr * item.quantity);
                            
                            return `
                                <tr>
                                    <td>
                                        <div style="display: flex; align-items: center; gap: 12px;">
                                            <div class="cart-item__image">
                                                <div class="product-image-placeholder small">
                                                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1">
                                                        <rect x="3" y="3" width="18" height="18" rx="2" ry="2"/>
                                                        <circle cx="8.5" cy="8.5" r="1.5"/>
                                                        <polyline points="21,15 16,10 5,21"/>
                                                    </svg>
                                                </div>
                                            </div>
                                            <div>
                                                <div class="cart-item__title">${product.title}</div>
                                                <div class="cart-item__meta" style="font-size: 12px; color: #666;">${product.fabric} • ${product.color}</div>
                                            </div>
                                        </div>
                                    </td>
                                    <td class="cart-item__price">${price.symbol}${price.amount}</td>
                                    <td>
                                        <input type="number" class="quantity-input" value="${item.quantity}" 
                                               min="1" data-product-id="${product.id}">
                                    </td>
                                    <td class="cart-item__price">${itemTotal.symbol}${itemTotal.amount}</td>
                                    <td>
                                        <button class="btn btn--ghost btn--sm remove-item-btn" data-product-id="${product.id}">
                                            Remove
                                        </button>
                                    </td>
                                </tr>
                            `;
                        }).join('')}
                    </tbody>
                </table>
            </div>
            
            <div class="cart-summary">
                <h3>Order Summary</h3>
                <div class="summary-row">
                    <span>Subtotal</span>
                    <span>${convertedSubtotal.symbol}${convertedSubtotal.amount}</span>
                </div>
                <div class="summary-row">
                    <span>Shipping</span>
                    <span>${shipping === 0 ? 'Free' : `${convertedShipping.symbol}${convertedShipping.amount}`}</span>
                </div>
                <div class="summary-row total">
                    <span>Total</span>
                    <span>${convertedTotal.symbol}${convertedTotal.amount}</span>
                </div>
                
                <div class="coupon-form">
                    <input type="text" class="form-control" placeholder="Coupon code" id="coupon-input">
                    <button type="button" class="btn btn--outline btn--sm mt-8" id="apply-coupon-btn">
                        Apply Coupon
                    </button>
                </div>
                
                <button class="btn btn--primary btn--full-width mt-16" data-page="checkout">
                    Proceed to Checkout
                </button>
            </div>
        `;

        this.attachCartEventListeners(container);
    }

    renderCheckoutPage() {
        const container = document.getElementById('checkout-content');
        const subtotal = this.calculateSubtotal();
        const shipping = this.calculateShipping(subtotal);
        const total = subtotal + shipping;
        const convertedSubtotal = this.convertPrice(subtotal);
        const convertedShipping = this.convertPrice(shipping);
        const convertedTotal = this.convertPrice(total);

        container.innerHTML = `
            <div style="display: grid; grid-template-columns: 2fr 1fr; gap: 32px;">
                <div class="checkout-form">
                    <div class="checkout-steps">
                        <div class="step active">
                            <h3>Contact Information</h3>
                            <form id="contact-form">
                                <div class="form-group">
                                    <label for="email" class="form-label">Email</label>
                                    <input type="email" id="email" class="form-control" required>
                                </div>
                            </form>
                        </div>
                        
                        <div class="step">
                            <h3>Shipping Address</h3>
                            <form id="shipping-form">
                                <div class="form-group">
                                    <label for="full-name" class="form-label">Full Name</label>
                                    <input type="text" id="full-name" class="form-control" required>
                                </div>
                                <div class="form-group">
                                    <label for="address" class="form-label">Address</label>
                                    <textarea id="address" class="form-control" rows="3" required></textarea>
                                </div>
                                <div class="form-group">
                                    <label for="city" class="form-label">City</label>
                                    <input type="text" id="city" class="form-control" required>
                                </div>
                                <div class="form-group">
                                    <label for="postal-code" class="form-label">Postal Code</label>
                                    <input type="text" id="postal-code" class="form-control" required>
                                </div>
                            </form>
                        </div>
                        
                        <div class="step">
                            <h3>Payment</h3>
                            <div class="payment-methods">
                                <div class="payment-method">
                                    <input type="radio" id="stripe" name="payment" value="stripe" checked>
                                    <label for="stripe">Credit Card (Stripe)</label>
                                </div>
                            </div>
                            <div class="stripe-placeholder" style="padding: 20px; border: 2px dashed var(--brand-primary); text-align: center; margin: 16px 0; border-radius: 8px; background: var(--brand-secondary);">
                                <strong>Stripe Payment Form</strong><br>
                                <small>(Test mode - use test card numbers)</small><br>
                                <small>4242 4242 4242 4242</small>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="checkout-summary">
                    <h3>Order Summary</h3>
                    <div class="cart-items-summary">
                        ${this.cart.map(item => {
                            const product = this.products.find(p => p.id === item.productId);
                            const itemTotal = this.convertPrice(product.price_inr * item.quantity);
                            return `
                                <div style="display: flex; justify-content: space-between; margin-bottom: 8px; padding-bottom: 8px; border-bottom: 1px solid rgba(91, 44, 111, 0.1);">
                                    <span>${product.title} × ${item.quantity}</span>
                                    <span>${itemTotal.symbol}${itemTotal.amount}</span>
                                </div>
                            `;
                        }).join('')}
                    </div>
                    <div class="summary-row">
                        <span>Subtotal</span>
                        <span>${convertedSubtotal.symbol}${convertedSubtotal.amount}</span>
                    </div>
                    <div class="summary-row">
                        <span>Shipping</span>
                        <span>${shipping === 0 ? 'Free' : `${convertedShipping.symbol}${convertedShipping.amount}`}</span>
                    </div>
                    <div class="summary-row total">
                        <span>Total</span>
                        <span>${convertedTotal.symbol}${convertedTotal.amount}</span>
                    </div>
                    
                    <button class="btn btn--primary btn--full-width mt-16" id="place-order-btn">
                        Complete Order
                    </button>
                </div>
            </div>
        `;

        document.getElementById('place-order-btn').addEventListener('click', () => {
            this.handleCheckout();
        });
    }

    renderAccountPage() {
        const container = document.getElementById('account-content');
        
        if (!this.currentUser) {
            container.innerHTML = `
                <div class="auth-forms">
                    <div class="auth-form-container">
                        <h3>Sign In to Your Account</h3>
                        <form class="auth-form" id="account-login-form">
                            <div class="form-group">
                                <label for="account-email" class="form-label">Email</label>
                                <input type="email" id="account-email" class="form-control" required>
                            </div>
                            <div class="form-group">
                                <label for="account-password" class="form-label">Password</label>
                                <input type="password" id="account-password" class="form-control" required>
                            </div>
                            <button type="submit" class="btn btn--primary btn--full-width">Sign In</button>
                            <p class="mt-16" style="text-align: center; font-size: 12px; color: #666;">
                                Demo: Use admin@vastram.com / admin for admin access
                            </p>
                        </form>
                        
                        <div class="auth-divider" style="margin: 24px 0; text-align: center; color: #666;">
                            or
                        </div>
                        
                        <form class="auth-form" id="account-register-form">
                            <h4>Create New Account</h4>
                            <div class="form-group">
                                <label for="register-name" class="form-label">Full Name</label>
                                <input type="text" id="register-name" class="form-control" required>
                            </div>
                            <div class="form-group">
                                <label for="register-email" class="form-label">Email</label>
                                <input type="email" id="register-email" class="form-control" required>
                            </div>
                            <div class="form-group">
                                <label for="register-password" class="form-label">Password</label>
                                <input type="password" id="register-password" class="form-control" required>
                            </div>
                            <button type="submit" class="btn btn--outline btn--full-width">Create Account</button>
                        </form>
                    </div>
                </div>
            `;

            document.getElementById('account-login-form').addEventListener('submit', (e) => {
                e.preventDefault();
                this.handleAccountLogin(e);
            });

            document.getElementById('account-register-form').addEventListener('submit', (e) => {
                e.preventDefault();
                this.handleAccountRegister(e);
            });
        } else {
            container.innerHTML = `
                <div class="user-profile">
                    <h3>Welcome, ${this.currentUser.name}!</h3>
                    
                    ${this.currentUser.role === 'admin' ? `
                        <div class="admin-notice" style="background: var(--brand-secondary); padding: 16px; border-radius: 8px; margin-bottom: 24px;">
                            <p><strong>Admin Access:</strong> You have administrative privileges.</p>
                            <button class="btn btn--primary" data-page="admin">Go to Admin Dashboard</button>
                        </div>
                    ` : ''}
                    
                    <div class="profile-section">
                        <h4>Profile Information</h4>
                        <p><strong>Name:</strong> ${this.currentUser.name}</p>
                        <p><strong>Email:</strong> ${this.currentUser.email}</p>
                        <p><strong>Role:</strong> ${this.currentUser.role}</p>
                    </div>
                    
                    <div class="orders-section">
                        <h4>Recent Orders</h4>
                        <p>No orders found.</p>
                    </div>
                    
                    <button class="btn btn--outline" id="logout-btn">Sign Out</button>
                </div>
            `;

            const adminBtn = container.querySelector('[data-page="admin"]');
            if (adminBtn) {
                adminBtn.addEventListener('click', (e) => {
                    e.preventDefault();
                    this.navigateTo('admin');
                });
            }

            document.getElementById('logout-btn').addEventListener('click', () => {
                this.handleLogout();
            });
        }
    }

    renderAdminPage() {
        if (!this.currentUser || this.currentUser.role !== 'admin') {
            this.navigateTo('account');
            return;
        }

        const container = document.getElementById('admin-content');
        
        container.innerHTML = `
            <div class="admin-stats">
                <div class="admin-stat-card">
                    <h3>₹45,280</h3>
                    <p>Sales Today</p>
                </div>
                <div class="admin-stat-card">
                    <h3>12</h3>
                    <p>Orders Pending</p>
                </div>
                <div class="admin-stat-card">
                    <h3>3</h3>
                    <p>Low Stock Items</p>
                </div>
                <div class="admin-stat-card">
                    <h3>${this.products.length}</h3>
                    <p>Total Products</p>
                </div>
            </div>
            
            <div class="admin-tabs">
                <div class="admin-tab-nav">
                    <button class="admin-tab-btn active" data-tab="products">Products</button>
                    <button class="admin-tab-btn" data-tab="orders">Orders</button>
                    <button class="admin-tab-btn" data-tab="customers">Customers</button>
                </div>
                
                <div class="admin-tab-content">
                    <div class="admin-tab-panel" id="admin-products">
                        <div class="admin-toolbar" style="margin-bottom: 24px;">
                            <button class="btn btn--primary" id="add-product-btn">Add New Product</button>
                        </div>
                        <div class="products-table" style="background: white; border-radius: 8px; overflow: hidden;">
                            <table style="width: 100%; border-collapse: collapse;">
                                <thead>
                                    <tr style="background: var(--brand-secondary);">
                                        <th style="padding: 12px; text-align: left;">Title</th>
                                        <th style="padding: 12px; text-align: left;">Fabric</th>
                                        <th style="padding: 12px; text-align: left;">Price</th>
                                        <th style="padding: 12px; text-align: left;">Stock</th>
                                        <th style="padding: 12px; text-align: left;">Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    ${this.products.map(product => `
                                        <tr style="border-bottom: 1px solid rgba(91, 44, 111, 0.1);">
                                            <td style="padding: 12px;">${product.title}</td>
                                            <td style="padding: 12px;">${product.fabric}</td>
                                            <td style="padding: 12px;">₹${product.price_inr}</td>
                                            <td style="padding: 12px;">${product.stock}</td>
                                            <td style="padding: 12px;">
                                                <button class="btn btn--ghost btn--sm edit-product-btn" data-id="${product.id}">Edit</button>
                                                <button class="btn btn--ghost btn--sm delete-product-btn" data-id="${product.id}" style="margin-left: 8px;">Delete</button>
                                            </td>
                                        </tr>
                                    `).join('')}
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        `;

        this.attachAdminEventListeners(container);
    }

    // Utility functions
    createProductCard(product) {
        const price = this.convertPrice(product.price_inr);
        const originalPrice = product.compare_at_inr ? this.convertPrice(product.compare_at_inr) : null;
        
        return `
            <div class="product-card" data-product-id="${product.id}">
                <div class="product-card__image">
                    <div class="product-image-placeholder">
                        <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1">
                            <rect x="3" y="3" width="18" height="18" rx="2" ry="2"/>
                            <circle cx="8.5" cy="8.5" r="1.5"/>
                            <polyline points="21,15 16,10 5,21"/>
                        </svg>
                        <p style="margin: 8px 0 0 0; font-size: 12px;">Saree Image</p>
                    </div>
                </div>
                <div class="product-card__content">
                    <h3 class="product-card__title">${product.title}</h3>
                    <div class="product-card__rating">
                        <div class="rating-stars">
                            ${this.generateStars(product.rating)}
                        </div>
                        <span class="rating-value">${product.rating}</span>
                    </div>
                    <div class="product-card__price">
                        <span class="product-card__current-price">${price.symbol}${price.amount}</span>
                        ${originalPrice ? `<span class="product-card__original-price">${originalPrice.symbol}${originalPrice.amount}</span>` : ''}
                    </div>
                    <div class="product-card__actions">
                        <button class="btn btn--primary btn--sm add-to-cart-btn" data-product-id="${product.id}">
                            ${this.t('product.add_to_cart')}
                        </button>
                        <button class="btn btn--ghost btn--sm view-product-btn" data-slug="${product.slug}">
                            View Details
                        </button>
                    </div>
                </div>
            </div>
        `;
    }

    attachProductCardListeners() {
        document.querySelectorAll('.add-to-cart-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.stopPropagation();
                const productId = parseInt(e.target.getAttribute('data-product-id'));
                this.addToCart(productId);
            });
        });

        document.querySelectorAll('.view-product-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.stopPropagation();
                const slug = e.target.getAttribute('data-slug');
                this.navigateTo('product', { slug });
            });
        });

        document.querySelectorAll('.product-card').forEach(card => {
            card.addEventListener('click', (e) => {
                const productId = parseInt(card.getAttribute('data-product-id'));
                const product = this.products.find(p => p.id === productId);
                if (product) {
                    this.navigateTo('product', { slug: product.slug });
                }
            });
        });
    }

    attachCartEventListeners(container) {
        container.querySelectorAll('.quantity-input').forEach(input => {
            input.addEventListener('change', (e) => {
                const productId = parseInt(e.target.getAttribute('data-product-id'));
                const newQuantity = parseInt(e.target.value);
                this.updateCartQuantity(productId, newQuantity);
            });
        });

        container.querySelectorAll('.remove-item-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const productId = parseInt(e.target.getAttribute('data-product-id'));
                this.removeFromCart(productId);
            });
        });

        const checkoutBtn = container.querySelector('[data-page="checkout"]');
        if (checkoutBtn) {
            checkoutBtn.addEventListener('click', (e) => {
                e.preventDefault();
                this.navigateTo('checkout');
            });
        }

        const applyCouponBtn = container.querySelector('#apply-coupon-btn');
        if (applyCouponBtn) {
            applyCouponBtn.addEventListener('click', () => {
                this.applyCoupon();
            });
        }
    }

    attachAdminEventListeners(container) {
        container.querySelectorAll('.admin-tab-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                container.querySelectorAll('.admin-tab-btn').forEach(b => b.classList.remove('active'));
                e.target.classList.add('active');
            });
        });

        container.querySelectorAll('.edit-product-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const productId = parseInt(e.target.getAttribute('data-id'));
                this.showNotification('Edit product functionality would go here');
            });
        });

        container.querySelectorAll('.delete-product-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const productId = parseInt(e.target.getAttribute('data-id'));
                if (confirm('Are you sure you want to delete this product?')) {
                    this.products = this.products.filter(p => p.id !== productId);
                    this.renderAdminPage();
                    this.showNotification('Product deleted');
                }
            });
        });
    }

    generateStars(rating) {
        const fullStars = Math.floor(rating);
        const hasHalfStar = rating % 1 >= 0.5;
        let stars = '';
        
        for (let i = 0; i < fullStars; i++) {
            stars += '★';
        }
        
        if (hasHalfStar) {
            stars += '☆';
        }
        
        while (stars.length < 5) {
            stars += '☆';
        }
        
        return stars;
    }

    convertPrice(priceInr) {
        const currency = this.currencies[this.currentCurrency];
        const convertedAmount = (priceInr * currency.rate).toFixed(2);
        return {
            symbol: currency.symbol,
            amount: convertedAmount
        };
    }

    formatPrice(amount) {
        const currency = this.currencies[this.currentCurrency];
        return `${currency.symbol}${amount.toFixed(2)}`;
    }

    addToCart(productId, quantity = 1) {
        const existingItem = this.cart.find(item => item.productId === productId);
        
        if (existingItem) {
            existingItem.quantity += quantity;
        } else {
            this.cart.push({ productId, quantity });
        }
        
        this.saveCart();
        this.updateCartCount();
        this.showNotification('Added to cart!');
    }

    removeFromCart(productId) {
        this.cart = this.cart.filter(item => item.productId !== productId);
        this.saveCart();
        this.updateCartCount();
        this.renderCartPage();
    }

    updateCartQuantity(productId, newQuantity) {
        const item = this.cart.find(item => item.productId === productId);
        if (item) {
            item.quantity = Math.max(1, newQuantity);
            this.saveCart();
            this.updateCartCount();
            this.renderCartPage();
        }
    }

    calculateSubtotal() {
        return this.cart.reduce((total, item) => {
            const product = this.products.find(p => p.id === item.productId);
            return total + (product.price_inr * item.quantity);
        }, 0);
    }

    calculateShipping(subtotal) {
        const shippingZone = this.shipping.IN; // Default to India
        return subtotal >= shippingZone.free_over ? 0 : shippingZone.flat_rate;
    }

    updateCartCount() {
        const count = this.cart.reduce((total, item) => total + item.quantity, 0);
        document.getElementById('cart-count').textContent = count;
    }

    loadCart() {
        const saved = localStorage.getItem('vastram-cart');
        if (saved) {
            this.cart = JSON.parse(saved);
        }
    }

    saveCart() {
        localStorage.setItem('vastram-cart', JSON.stringify(this.cart));
    }

    getFilteredProducts() {
        let filtered = [...this.products];
        
        if (this.filters.search) {
            const search = this.filters.search.toLowerCase();
            filtered = filtered.filter(p => 
                p.title.toLowerCase().includes(search) ||
                p.description.toLowerCase().includes(search)
            );
        }
        
        if (this.filters.fabric) {
            filtered = filtered.filter(p => p.fabric === this.filters.fabric);
        }
        
        if (this.filters.color) {
            filtered = filtered.filter(p => p.color === this.filters.color);
        }
        
        if (this.filters.occasion) {
            filtered = filtered.filter(p => p.occasion === this.filters.occasion);
        }
        
        // Sort
        switch (this.filters.sort) {
            case 'price-low':
                filtered.sort((a, b) => a.price_inr - b.price_inr);
                break;
            case 'price-high':
                filtered.sort((a, b) => b.price_inr - a.price_inr);
                break;
            case 'rating':
                filtered.sort((a, b) => b.rating - a.rating);
                break;
        }
        
        return filtered;
    }

    updateFilters(e) {
        const filterType = e.target.className.split(' ').find(cls => cls.startsWith('filter-')).replace('filter-', '');
        this.filters[filterType] = e.target.value;
        
        if (this.currentPage === 'collections') {
            this.renderCollectionsPage();
        }
    }

    toggleSearchModal() {
        const modal = document.getElementById('search-modal');
        modal.classList.toggle('hidden');
        
        if (!modal.classList.contains('hidden')) {
            document.querySelector('.search-input').focus();
        }
    }

    handleSearch(query) {
        if (query.length < 2) return;
        
        const results = this.products.filter(p => 
            p.title.toLowerCase().includes(query.toLowerCase()) ||
            p.fabric.toLowerCase().includes(query.toLowerCase()) ||
            p.color.toLowerCase().includes(query.toLowerCase())
        ).slice(0, 5);
        
        const resultsContainer = document.getElementById('search-results');
        
        if (results.length === 0) {
            resultsContainer.innerHTML = '<p class="empty-state">No products found</p>';
            return;
        }
        
        resultsContainer.innerHTML = results.map(product => {
            const price = this.convertPrice(product.price_inr);
            return `
                <div class="search-result" data-slug="${product.slug}" style="padding: 12px; border-bottom: 1px solid rgba(91, 44, 111, 0.1); cursor: pointer;">
                    <strong>${product.title}</strong>
                    <p style="margin: 4px 0 0 0; font-size: 14px; color: #666;">${product.fabric} • ${product.color} • ${price.symbol}${price.amount}</p>
                </div>
            `;
        }).join('');
        
        resultsContainer.querySelectorAll('.search-result').forEach(result => {
            result.addEventListener('click', (e) => {
                const slug = e.currentTarget.getAttribute('data-slug');
                this.toggleSearchModal();
                this.navigateTo('product', { slug });
            });
        });
    }

    handleNewsletterSignup(e) {
        const email = e.target.querySelector('input[type="email"]').value;
        this.showNotification('Thank you for subscribing to Vastram Circle!');
        e.target.reset();
    }

    handleLogin(e) {
        const email = e.target.querySelector('#login-email').value;
        const password = e.target.querySelector('#login-password').value;
        
        // Mock login - in real app, this would call an API
        if (email === 'admin@vastram.com' && password === 'admin') {
            this.currentUser = { id: 1, name: 'Admin User', email: email, role: 'admin' };
        } else {
            this.currentUser = { id: 2, name: 'Customer', email: email, role: 'customer' };
        }
        
        this.closeAllModals();
        this.showNotification('Welcome back!');
        
        if (this.currentPage === 'account') {
            this.renderAccountPage();
        }
    }

    handleAccountLogin(e) {
        const email = e.target.querySelector('#account-email').value;
        const password = e.target.querySelector('#account-password').value;
        
        if (email === 'admin@vastram.com' && password === 'admin') {
            this.currentUser = { id: 1, name: 'Admin User', email: email, role: 'admin' };
        } else {
            this.currentUser = { id: 2, name: 'Customer', email: email, role: 'customer' };
        }
        
        this.showNotification('Signed in successfully!');
        this.renderAccountPage();
    }

    handleAccountRegister(e) {
        const name = e.target.querySelector('#register-name').value;
        const email = e.target.querySelector('#register-email').value;
        const password = e.target.querySelector('#register-password').value;
        
        this.currentUser = { id: Date.now(), name: name, email: email, role: 'customer' };
        this.showNotification('Account created successfully!');
        this.renderAccountPage();
    }

    handleLogout() {
        this.currentUser = null;
        this.showNotification('Signed out successfully');
        this.renderAccountPage();
    }

    handleCheckout() {
        this.showNotification('Order placed successfully! Thank you for shopping with Vastram. (Demo mode)');
        this.cart = [];
        this.saveCart();
        this.updateCartCount();
        this.navigateTo('home');
    }

    applyCoupon() {
        const code = document.getElementById('coupon-input').value.toUpperCase();
        const coupon = this.coupons.find(c => c.code === code);
        
        if (coupon) {
            const subtotal = this.calculateSubtotal();
            if (subtotal >= coupon.min_subtotal) {
                this.showNotification(`Coupon applied! ${coupon.value}% off`);
            } else {
                this.showNotification(`Minimum order of ₹${coupon.min_subtotal} required`);
            }
        } else {
            this.showNotification('Invalid coupon code');
        }
    }

    switchAuthForm(formType) {
        // Implementation for switching between login and register forms
        console.log('Switching to', formType);
    }

    closeAllModals() {
        document.querySelectorAll('.modal').forEach(modal => {
            modal.classList.add('hidden');
        });
        
        document.getElementById('search-modal').classList.add('hidden');
    }

    updateLanguage() {
        // Update text content based on current language
        document.querySelectorAll('[data-i18n]').forEach(element => {
            const key = element.getAttribute('data-i18n');
            element.textContent = this.t(key);
        });
    }

    t(key) {
        return this.translations[this.currentLanguage][key] || key;
    }

    showNotification(message) {
        // Create and show a temporary notification
        const notification = document.createElement('div');
        notification.className = 'notification';
        notification.textContent = message;
        notification.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            background: var(--brand-primary);
            color: white;
            padding: 12px 24px;
            border-radius: 8px;
            z-index: 1000;
            animation: slideIn 0.3s ease;
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        `;
        
        document.body.appendChild(notification);
        
        setTimeout(() => {
            notification.remove();
        }, 3000);
    }

    debounce(func, wait) {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                clearTimeout(timeout);
                func(...args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    }
}

// Add CSS for notification animation and image placeholders
const style = document.createElement('style');
style.textContent = `
    @keyframes slideIn {
        from {
            transform: translateX(100%);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }
    
    .product-image-placeholder {
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        width: 100%;
        height: 100%;
        background: linear-gradient(135deg, var(--brand-secondary) 0%, rgba(229, 212, 243, 0.5) 100%);
        color: var(--brand-primary);
        text-align: center;
        border-radius: 4px;
    }
    
    .product-image-placeholder.small {
        width: 60px;
        height: 60px;
        border-radius: 4px;
    }
    
    .product-image-placeholder svg {
        opacity: 0.6;
        margin-bottom: 4px;
    }
    
    .product-image-placeholder p {
        font-size: 12px;
        margin: 0;
        opacity: 0.8;
    }
`;
document.head.appendChild(style);

// Initialize the app when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.vastramApp = new VastramApp();
});