interface SuccessScreenProps {
  onBackToWelcome: () => void;
}

export function SuccessScreen({ onBackToWelcome }: SuccessScreenProps) {
  const handleBackToHome = () => {
    console.log('Back to home button clicked'); // Debug log
    if (onBackToWelcome) {
      onBackToWelcome();
    } else {
      console.error('onBackToWelcome function not provided');
    }
  };

  const handleGetStarted = () => {
    console.log('Get started clicked');
    // For now, also navigate back to welcome
    handleBackToHome();
  };

  return (
    <div className="h-screen flex flex-col items-center justify-center px-10 bg-background relative overflow-hidden">
      {/* Background Animation */}
      <div className="absolute inset-0 flex items-center justify-center opacity-5">
        <div className="w-96 h-96 rounded-full border-2 border-[#4A90E2] animate-pulse"></div>
      </div>

      {/* Success Illustration */}
      <div className="mb-8">
        <svg
          width="200"
          height="200"
          viewBox="0 0 200 200"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className="drop-shadow-lg"
        >
          {/* Background Circle */}
          <circle cx="100" cy="100" r="85" fill="#4A90E2" opacity="0.1" />
          
          {/* Main Success Circle */}
          <circle cx="100" cy="100" r="60" fill="#4A90E2" className="animate-pulse">
            <animate attributeName="r" values="60;65;60" dur="2s" repeatCount="indefinite" />
          </circle>
          
          {/* Checkmark */}
          <path 
            d="M75 100 L90 115 L125 80" 
            stroke="white" 
            strokeWidth="8" 
            strokeLinecap="round" 
            strokeLinejoin="round" 
            fill="none"
          >
            <animate attributeName="stroke-dasharray" values="0 100;100 0" dur="1s" />
            <animate attributeName="stroke-dashoffset" values="100;0" dur="1s" />
          </path>
          
          {/* Confetti */}
          <rect x="40" y="30" width="6" height="6" fill="#4A90E2" opacity="0.8" transform="rotate(45 43 33)">
            <animate attributeName="y" values="30;170" dur="3s" repeatCount="indefinite" />
            <animate attributeName="opacity" values="0.8;0" dur="3s" repeatCount="indefinite" />
          </rect>
          <rect x="160" y="40" width="4" height="4" fill="#4A90E2" opacity="0.6" transform="rotate(45 162 42)">
            <animate attributeName="y" values="40;180" dur="2.5s" repeatCount="indefinite" />
            <animate attributeName="opacity" values="0.6;0" dur="2.5s" repeatCount="indefinite" />
          </rect>
          <circle cx="50" cy="50" r="3" fill="#4A90E2" opacity="0.7">
            <animate attributeName="cy" values="50;170" dur="2.8s" repeatCount="indefinite" />
            <animate attributeName="opacity" values="0.7;0" dur="2.8s" repeatCount="indefinite" />
          </circle>
          <circle cx="150" cy="35" r="2" fill="#4A90E2" opacity="0.5">
            <animate attributeName="cy" values="35;175" dur="3.2s" repeatCount="indefinite" />
            <animate attributeName="opacity" values="0.5;0" dur="3.2s" repeatCount="indefinite" />
          </circle>
          
          {/* Sparkles */}
          <g opacity="0.8">
            <path d="M30 80 L35 85 L30 90 L25 85 Z" fill="#4A90E2">
              <animate attributeName="opacity" values="0.8;0.3;0.8" dur="1.5s" repeatCount="indefinite" />
            </path>
            <path d="M170 70 L175 75 L170 80 L165 75 Z" fill="#4A90E2">
              <animate attributeName="opacity" values="0.3;0.8;0.3" dur="2s" repeatCount="indefinite" />
            </path>
            <path d="M45 130 L50 135 L45 140 L40 135 Z" fill="#4A90E2">
              <animate attributeName="opacity" values="0.8;0.3;0.8" dur="1.8s" repeatCount="indefinite" />
            </path>
          </g>
        </svg>
      </div>

      {/* Success Message */}
      <div className="text-center mb-12">
        <h1 className="text-2xl font-medium text-foreground mb-4">
          Welcome Aboard! 🎉
        </h1>
        <p className="text-muted-foreground text-base max-w-[280px] leading-relaxed">
          Your account has been successfully created. You're now part of our amazing community!
        </p>
      </div>

      {/* Action Buttons */}
      <div className="w-full max-w-[250px] space-y-4 mb-16">
        <button 
          onClick={handleGetStarted}
          className="w-full h-12 bg-[#4A90E2] text-white rounded-lg font-medium hover:bg-[#3A7BC8] hover:scale-105 transition-all duration-200 shadow-lg hover:shadow-xl"
        >
          Get Started
        </button>
        
        <button 
          onClick={handleBackToHome}
          className="w-full h-12 bg-background border border-[#4A90E2] text-[#4A90E2] rounded-lg font-medium hover:bg-[#4A90E2] hover:text-white hover:scale-105 transition-all duration-200 shadow-sm hover:shadow-lg"
        >
          Back to Home
        </button>
      </div>

      {/* Fun fact */}
      <div className="text-center mb-8">
        <p className="text-xs text-muted-foreground opacity-60">
          🌟 You're user #1,234 to join us this month!
        </p>
      </div>

      {/* Copyright */}
      <div className="absolute bottom-4 left-0 right-0 text-center">
        <p className="text-xs text-muted-foreground">
          All copy rights are reserved to the 2025, community policies
        </p>
      </div>
    </div>
  );
}