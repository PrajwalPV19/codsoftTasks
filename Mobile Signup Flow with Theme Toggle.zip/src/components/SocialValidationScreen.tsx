import { useState } from 'react';
import { CheckCircle, User, Mail } from 'lucide-react';

interface SocialValidationScreenProps {
  userData: {
    provider: 'google' | 'facebook';
    name: string;
    email: string;
  };
  onBackClick: () => void;
  onContinueClick: () => void;
}

export function SocialValidationScreen({ userData, onBackClick, onContinueClick }: SocialValidationScreenProps) {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [additionalInfo, setAdditionalInfo] = useState({
    phoneNumber: '',
    agreeToTerms: false
  });

  const handleContinue = async () => {
    setIsSubmitting(true);
    
    // Simulate API call to create account
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    setIsSubmitting(false);
    onContinueClick();
  };

  const canContinue = additionalInfo.agreeToTerms;

  const providerConfig = {
    google: {
      name: 'Google',
      color: '#4285F4',
      icon: (
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
          <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
          <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
          <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/>
          <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
        </svg>
      )
    },
    facebook: {
      name: 'Facebook',
      color: '#1877F2',
      icon: (
        <svg width="24" height="24" viewBox="0 0 24 24" fill="#1877F2">
          <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
        </svg>
      )
    }
  };

  const config = providerConfig[userData.provider];

  return (
    <div className="h-screen px-10 pt-16 bg-background relative overflow-hidden">
      {/* Background Graphics */}
      <div className="absolute top-0 right-0 opacity-10">
        <svg width="150" height="150" viewBox="0 0 150 150" fill="none">
          <circle cx="75" cy="75" r="60" stroke="#4A90E2" strokeWidth="2" />
          <circle cx="75" cy="75" r="40" stroke="#4A90E2" strokeWidth="1" opacity="0.5" />
          <circle cx="75" cy="75" r="20" stroke="#4A90E2" strokeWidth="1" opacity="0.3" />
        </svg>
      </div>

      {/* Header */}
      <div className="text-center mb-8">
        <h2 className="text-xl font-medium text-foreground mb-2">Confirm Your Account</h2>
        <p className="text-sm text-muted-foreground">Review your information from {config.name}</p>
      </div>

      {/* Provider Info */}
      <div className="mb-6">
        <div className="flex items-center justify-center space-x-3 p-4 bg-muted/50 dark:bg-muted/20 rounded-lg border border-border">
          {config.icon}
          <span className="text-sm text-muted-foreground">Connected with {config.name}</span>
          <CheckCircle className="w-5 h-5 text-green-500" />
        </div>
      </div>

      {/* User Information */}
      <div className="space-y-4 mb-6">
        {/* Name */}
        <div className="space-y-2">
          <label className="block text-sm font-medium text-foreground">
            Full Name
          </label>
          <div className="relative">
            <User className="absolute left-3 top-2.5 w-5 h-5 text-muted-foreground" />
            <input
              value={userData.name}
              readOnly
              className="w-full h-10 pl-10 pr-10 bg-input-background dark:bg-[#1E1E1E] border border-[#E0E0E0] dark:border-[#333333] rounded-lg text-foreground cursor-not-allowed"
            />
            <CheckCircle className="absolute right-3 top-2.5 w-5 h-5 text-green-500" />
          </div>
        </div>

        {/* Email */}
        <div className="space-y-2">
          <label className="block text-sm font-medium text-foreground">
            Email Address
          </label>
          <div className="relative">
            <Mail className="absolute left-3 top-2.5 w-5 h-5 text-muted-foreground" />
            <input
              value={userData.email}
              readOnly
              className="w-full h-10 pl-10 pr-10 bg-input-background dark:bg-[#1E1E1E] border border-[#E0E0E0] dark:border-[#333333] rounded-lg text-foreground cursor-not-allowed"
            />
            <CheckCircle className="absolute right-3 top-2.5 w-5 h-5 text-green-500" />
          </div>
        </div>

        {/* Optional Phone Number */}
        <div className="space-y-2">
          <label className="block text-sm font-medium text-foreground">
            Phone Number <span className="text-muted-foreground">(Optional)</span>
          </label>
          <input
            type="tel"
            value={additionalInfo.phoneNumber}
            onChange={(e) => setAdditionalInfo(prev => ({ ...prev, phoneNumber: e.target.value }))}
            className="w-full h-10 px-3 bg-input-background dark:bg-[#1E1E1E] border border-[#E0E0E0] dark:border-[#333333] rounded-lg text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-[#4A90E2] focus:border-transparent transition-all"
            placeholder="Enter your phone number"
          />
        </div>
      </div>

      {/* Terms Agreement */}
      <div className="mb-8">
        <label className="flex items-start space-x-3 cursor-pointer">
          <input
            type="checkbox"
            checked={additionalInfo.agreeToTerms}
            onChange={(e) => setAdditionalInfo(prev => ({ ...prev, agreeToTerms: e.target.checked }))}
            className="mt-1 w-4 h-4 text-[#4A90E2] border border-gray-300 rounded focus:ring-[#4A90E2] focus:ring-2"
          />
          <span className="text-sm text-[#555555] dark:text-[#AAAAAA]">
            I agree to the Terms of Service and Privacy Policy
          </span>
        </label>
      </div>

      {/* Continue Button */}
      <div className="flex justify-center mb-8">
        <button
          onClick={handleContinue}
          disabled={!canContinue || isSubmitting}
          className={`w-[200px] h-12 rounded-lg font-medium transition-all duration-200 flex items-center justify-center ${
            canContinue && !isSubmitting
              ? 'bg-[#4A90E2] text-white hover:bg-[#3A7BC8] hover:scale-105 shadow-lg hover:shadow-xl'
              : 'bg-gray-300 dark:bg-gray-600 text-gray-500 dark:text-gray-400 cursor-not-allowed'
          }`}
        >
          {isSubmitting ? (
            <div className="flex items-center space-x-2">
              <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
              <span>Creating Account...</span>
            </div>
          ) : (
            'Create Account'
          )}
        </button>
      </div>

      {/* Back Button */}
      <div className="absolute bottom-12 left-10">
        <button
          onClick={onBackClick}
          className="text-[#4A90E2] text-sm underline hover:no-underline transition-all"
        >
          ← Back to Welcome
        </button>
      </div>

      {/* Info Note */}
      <div className="absolute bottom-12 right-10 max-w-[200px]">
        <p className="text-xs text-muted-foreground text-right">
          Your {config.name} account will be linked to your new account
        </p>
      </div>

      {/* Copyright */}
      <div className="absolute bottom-4 left-0 right-0 text-center">
        <p className="text-xs text-muted-foreground">
          All copy rights are reserved to the 2025, community policies
        </p>
      </div>
    </div>
  );
}