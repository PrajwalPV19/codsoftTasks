import { SocialButton } from './SocialButton';

interface WelcomeScreenProps {
  onSignUpClick: () => void;
  onLoginClick: () => void;
  onSocialSignIn: (userData: { provider: 'google' | 'facebook'; name: string; email: string }) => void;
}

export function WelcomeScreen({ onSignUpClick, onLoginClick, onSocialSignIn }: WelcomeScreenProps) {
  const handleSocialSignIn = (provider: 'google' | 'facebook') => {
    console.log(`Signing in with ${provider}`);
    
    // Simulate fetching user data from social provider
    const mockUserData = {
      provider,
      name: provider === 'google' ? 'John Smith' : 'Jane Doe',
      email: provider === 'google' ? 'john.smith@gmail.com' : 'jane.doe@facebook.com'
    };
    
    onSocialSignIn(mockUserData);
  };

  return (
    <div className="h-screen flex flex-col items-center justify-between px-10 bg-background">
      {/* Top Section with Illustration */}
      <div className="flex-1 flex flex-col items-center justify-center pt-20">
        {/* Welcome Illustration */}
        <div className="mb-8">
          <svg
            width="200"
            height="160"
            viewBox="0 0 200 160"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
            className="drop-shadow-lg"
          >
            {/* Background Circle */}
            <circle cx="100" cy="80" r="75" fill="#4A90E2" opacity="0.1" />
            
            {/* Main Character */}
            <circle cx="100" cy="60" r="25" fill="#4A90E2" />
            <rect x="85" y="85" width="30" height="45" rx="15" fill="#4A90E2" />
            
            {/* Arms */}
            <circle cx="70" cy="95" r="8" fill="#4A90E2" />
            <circle cx="130" cy="95" r="8" fill="#4A90E2" />
            
            {/* Welcome gestures */}
            <path d="M65 85 Q55 75 60 65" stroke="#4A90E2" strokeWidth="3" strokeLinecap="round" fill="none" />
            <path d="M135 85 Q145 75 140 65" stroke="#4A90E2" strokeWidth="3" strokeLinecap="round" fill="none" />
            
            {/* Floating elements */}
            <circle cx="60" cy="40" r="3" fill="#4A90E2" opacity="0.6">
              <animate attributeName="cy" values="40;35;40" dur="2s" repeatCount="indefinite" />
            </circle>
            <circle cx="140" cy="45" r="2" fill="#4A90E2" opacity="0.4">
              <animate attributeName="cy" values="45;40;45" dur="2.5s" repeatCount="indefinite" />
            </circle>
            <circle cx="50" cy="120" r="2.5" fill="#4A90E2" opacity="0.5">
              <animate attributeName="cy" values="120;115;120" dur="3s" repeatCount="indefinite" />
            </circle>
          </svg>
        </div>

        {/* Main Heading */}
        <h1 className="text-2xl text-center text-foreground font-medium mb-2">
          Join Us
        </h1>
        <p className="text-center text-muted-foreground text-sm mb-8 max-w-[250px]">
          Create your account and become part of our amazing community
        </p>
      </div>

      {/* Bottom Section with Buttons */}
      <div className="w-full max-w-[280px] space-y-4 pb-16">
        {/* Social Sign-In Buttons */}
        <div className="space-y-3">
          <SocialButton 
            provider="google" 
            onClick={() => handleSocialSignIn('google')} 
          />
          <SocialButton 
            provider="facebook" 
            onClick={() => handleSocialSignIn('facebook')} 
          />
        </div>

        {/* Divider */}
        <div className="flex items-center space-x-4 my-6">
          <div className="flex-1 h-px bg-border"></div>
          <span className="text-sm text-muted-foreground">or</span>
          <div className="flex-1 h-px bg-border"></div>
        </div>

        {/* Traditional Sign-up/Login */}
        <div className="space-y-3">
          {/* Sign Up Button */}
          <button
            onClick={onSignUpClick}
            className="w-full h-12 bg-[#4A90E2] text-white rounded-lg font-medium hover:bg-[#3A7BC8] hover:scale-105 transition-all duration-200 shadow-lg hover:shadow-xl"
          >
            Sign Up with Email
          </button>

          {/* Log In Button */}
          <button 
            onClick={onLoginClick}
            className="w-full h-12 bg-background border border-[#4A90E2] text-[#4A90E2] rounded-lg font-medium hover:bg-[#4A90E2] hover:text-white hover:scale-105 transition-all duration-200 shadow-sm hover:shadow-lg"
          >
            Log In
          </button>
        </div>
      </div>

      {/* Copyright */}
      <div className="absolute bottom-4 left-0 right-0 text-center">
        <p className="text-xs text-muted-foreground">
          All copy rights are reserved to the 2025, community policies
        </p>
      </div>
    </div>
  );
}