import { useState } from 'react';
import { CheckCircle, AlertCircle, Eye, EyeOff } from 'lucide-react';
import { SocialButton } from './SocialButton';

interface LoginScreenProps {
  onBackClick: () => void;
  onLoginSuccess: () => void;
  onSocialSignIn: (userData: { provider: 'google' | 'facebook'; name: string; email: string }) => void;
}

export function LoginScreen({ onBackClick, onLoginSuccess, onSocialSignIn }: LoginScreenProps) {
  const [formData, setFormData] = useState({
    email: '',
    password: ''
  });

  const [errors, setErrors] = useState({
    email: '',
    password: ''
  });

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showPassword, setShowPassword] = useState(false);

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
    
    // Clear error when user starts typing
    if (errors[field as keyof typeof errors]) {
      setErrors(prev => ({
        ...prev,
        [field]: ''
      }));
    }
  };

  const validateForm = () => {
    const newErrors = {
      email: '',
      password: ''
    };

    if (!formData.email.trim()) {
      newErrors.email = 'Email is required';
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      newErrors.email = 'Please enter a valid email';
    }

    if (!formData.password) {
      newErrors.password = 'Password is required';
    }

    setErrors(newErrors);
    return !Object.values(newErrors).some(error => error !== '');
  };

  const handleLogin = async () => {
    if (!validateForm()) {
      return;
    }

    setIsSubmitting(true);
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    setIsSubmitting(false);
    onLoginSuccess();
  };

  const handleSocialSignIn = async (provider: 'google' | 'facebook') => {
    console.log(`Logging in with ${provider}`);
    setIsSubmitting(true);
    
    // Simulate social auth API call
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    // Simulate fetching user data from social provider
    const mockUserData = {
      provider,
      name: provider === 'google' ? 'John Smith' : 'Jane Doe',
      email: provider === 'google' ? 'john.smith@gmail.com' : 'jane.doe@facebook.com'
    };
    
    setIsSubmitting(false);
    onSocialSignIn(mockUserData);
  };

  const isFormValid = formData.email && formData.password && !Object.values(errors).some(error => error !== '');

  return (
    <div className="h-screen px-10 pt-12 bg-background relative overflow-hidden">
      {/* Background Graphics */}
      <div className="absolute top-0 right-0 opacity-10">
        <svg width="150" height="150" viewBox="0 0 150 150" fill="none">
          <circle cx="75" cy="75" r="60" stroke="#4A90E2" strokeWidth="2" />
          <circle cx="75" cy="75" r="40" stroke="#4A90E2" strokeWidth="1" opacity="0.5" />
          <circle cx="75" cy="75" r="20" stroke="#4A90E2" strokeWidth="1" opacity="0.3" />
        </svg>
      </div>

      {/* Header */}
      <div className="text-center mb-8">
        <h2 className="text-xl font-medium text-foreground mb-2">Welcome Back</h2>
        <p className="text-sm text-muted-foreground">Sign in to your account</p>
      </div>

      {/* Social Sign-In Options */}
      <div className="mb-8">
        <div className="space-y-3 max-w-[280px] mx-auto">
          <SocialButton 
            provider="google" 
            onClick={() => handleSocialSignIn('google')}
            disabled={isSubmitting}
          />
          <SocialButton 
            provider="facebook" 
            onClick={() => handleSocialSignIn('facebook')}
            disabled={isSubmitting}
          />
        </div>

        {/* Divider */}
        <div className="flex items-center space-x-4 my-6 max-w-[280px] mx-auto">
          <div className="flex-1 h-px bg-border"></div>
          <span className="text-sm text-muted-foreground">or</span>
          <div className="flex-1 h-px bg-border"></div>
        </div>
      </div>

      {/* Form Container */}
      <div className="space-y-6 max-h-[calc(100vh-400px)] overflow-y-auto">
        {/* Email */}
        <div className="space-y-2">
          <label htmlFor="email" className="block text-sm font-medium text-foreground">
            Email
          </label>
          <div className="relative">
            <input
              id="email"
              type="email"
              value={formData.email}
              onChange={(e) => handleInputChange('email', e.target.value)}
              className={`w-full h-12 px-3 pr-10 bg-input-background dark:bg-[#1E1E1E] border rounded-lg text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-[#4A90E2] focus:border-transparent transition-all ${
                errors.email ? 'border-red-500' : 'border-[#E0E0E0] dark:border-[#333333]'
              }`}
              placeholder="Enter your email"
            />
            {formData.email && !errors.email && /\S+@\S+\.\S+/.test(formData.email) && (
              <CheckCircle className="absolute right-3 top-3 w-6 h-6 text-green-500" />
            )}
            {errors.email && (
              <AlertCircle className="absolute right-3 top-3 w-6 h-6 text-red-500" />
            )}
          </div>
          {errors.email && (
            <p className="text-xs text-red-500">{errors.email}</p>
          )}
        </div>

        {/* Password */}
        <div className="space-y-2">
          <label htmlFor="password" className="block text-sm font-medium text-foreground">
            Password
          </label>
          <div className="relative">
            <input
              id="password"
              type={showPassword ? 'text' : 'password'}
              value={formData.password}
              onChange={(e) => handleInputChange('password', e.target.value)}
              className={`w-full h-12 px-3 pr-20 bg-input-background dark:bg-[#1E1E1E] border rounded-lg text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-[#4A90E2] focus:border-transparent transition-all ${
                errors.password ? 'border-red-500' : 'border-[#E0E0E0] dark:border-[#333333]'
              }`}
              placeholder="Enter your password"
            />
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className="absolute right-10 top-3 w-6 h-6 text-muted-foreground hover:text-foreground transition-colors"
            >
              {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
            </button>
            {formData.password && !errors.password && (
              <CheckCircle className="absolute right-3 top-3 w-6 h-6 text-green-500" />
            )}
            {errors.password && (
              <AlertCircle className="absolute right-3 top-3 w-6 h-6 text-red-500" />
            )}
          </div>
          {errors.password && (
            <p className="text-xs text-red-500">{errors.password}</p>
          )}
        </div>

        {/* Forgot Password */}
        <div className="text-right">
          <button className="text-sm text-[#4A90E2] hover:underline">
            Forgot your password?
          </button>
        </div>

        {/* Login Button */}
        <div className="pt-4">
          <div className="flex justify-center">
            <button
              onClick={handleLogin}
              disabled={!isFormValid || isSubmitting}
              className={`w-[200px] h-12 rounded-lg font-medium transition-all duration-200 flex items-center justify-center ${
                isFormValid && !isSubmitting
                  ? 'bg-[#4A90E2] text-white hover:bg-[#3A7BC8] hover:scale-105 shadow-lg hover:shadow-xl'
                  : 'bg-gray-300 dark:bg-gray-600 text-gray-500 dark:text-gray-400 cursor-not-allowed'
              }`}
            >
              {isSubmitting ? (
                <div className="flex items-center space-x-2">
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                  <span>Signing In...</span>
                </div>
              ) : (
                'Sign In'
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Back Button */}
      <div className="absolute bottom-12 left-10">
        <button
          onClick={onBackClick}
          className="text-[#4A90E2] text-sm underline hover:no-underline transition-all"
        >
          ← Back to Welcome
        </button>
      </div>

      {/* Copyright */}
      <div className="absolute bottom-4 left-0 right-0 text-center">
        <p className="text-xs text-muted-foreground">
          All copy rights are reserved to the 2025, community policies
        </p>
      </div>
    </div>
  );
}