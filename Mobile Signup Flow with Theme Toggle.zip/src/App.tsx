import { useState, useEffect } from 'react';
import { Moon, Sun } from 'lucide-react';
import { WelcomeScreen } from './components/WelcomeScreen';
import { SignupScreen } from './components/SignupScreen';
import { LoginScreen } from './components/LoginScreen';
import { SocialValidationScreen } from './components/SocialValidationScreen';
import { SuccessScreen } from './components/SuccessScreen';

export default function App() {
  const [currentScreen, setCurrentScreen] = useState<'welcome' | 'signup' | 'login' | 'social-validation' | 'success'>('welcome');
  const [isDark, setIsDark] = useState(false);
  const [socialUserData, setSocialUserData] = useState<{
    provider: 'google' | 'facebook';
    name: string;
    email: string;
  } | null>(null);

  useEffect(() => {
    if (isDark) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [isDark]);

  const toggleTheme = () => {
    setIsDark(!isDark);
  };

  const navigateToSignup = () => {
    console.log('Navigating to signup');
    setCurrentScreen('signup');
  };

  const navigateToLogin = () => {
    console.log('Navigating to login');
    setCurrentScreen('login');
  };

  const navigateToSocialValidation = (userData: { provider: 'google' | 'facebook'; name: string; email: string }) => {
    console.log('Navigating to social validation', userData);
    setSocialUserData(userData);
    setCurrentScreen('social-validation');
  };

  const navigateToSuccess = () => {
    console.log('Navigating to success');
    setCurrentScreen('success');
  };

  const navigateToWelcome = () => {
    console.log('Navigating to welcome');
    setCurrentScreen('welcome');
    setSocialUserData(null);
  };

  return (
    <div className="min-h-screen bg-background transition-colors duration-300">
      <div className="mx-auto max-w-[390px] min-h-screen relative bg-background">
        {/* Theme Toggle */}
        <button
          onClick={toggleTheme}
          className="absolute top-5 right-5 z-10 p-2 rounded-full hover:bg-muted transition-colors"
          aria-label="Toggle theme"
        >
          {isDark ? (
            <Sun className="w-6 h-6 text-[#4A90E2]" />
          ) : (
            <Moon className="w-6 h-6 text-[#4A90E2]" />
          )}
        </button>

        {/* Screen Content */}
        {currentScreen === 'welcome' && (
          <WelcomeScreen 
            onSignUpClick={navigateToSignup}
            onLoginClick={navigateToLogin}
            onSocialSignIn={navigateToSocialValidation}
          />
        )}
        {currentScreen === 'signup' && (
          <SignupScreen 
            onBackClick={navigateToWelcome} 
            onContinueClick={navigateToSuccess}
            onSocialSignIn={navigateToSocialValidation}
          />
        )}
        {currentScreen === 'login' && (
          <LoginScreen 
            onBackClick={navigateToWelcome} 
            onLoginSuccess={navigateToSuccess}
            onSocialSignIn={navigateToSocialValidation}
          />
        )}
        {currentScreen === 'social-validation' && socialUserData && (
          <SocialValidationScreen 
            userData={socialUserData}
            onBackClick={navigateToWelcome}
            onContinueClick={navigateToSuccess}
          />
        )}
        {currentScreen === 'success' && (
          <SuccessScreen onBackToWelcome={navigateToWelcome} />
        )}
      </div>
    </div>
  );
}