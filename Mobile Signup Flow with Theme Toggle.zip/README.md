
  # Mobile Signup Flow with Theme Toggle

  This is a code bundle for Mobile Signup Flow with Theme Toggle. The original project is available at https://www.figma.com/design/N68Oi2utJf7RqqGBtg6cfi/Mobile-Signup-Flow-with-Theme-Toggle.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  